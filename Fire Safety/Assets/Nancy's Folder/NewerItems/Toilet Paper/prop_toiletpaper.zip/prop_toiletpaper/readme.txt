Thank you for supporting me by downloading this package!

Please leave your feedback at http://www.tehnewdev.tumblr.com/
Your support and feedback is truly appreciated.

You may use this package in personal projects and commercial projects. I have included all of the source files for you to freely modify if needed. You can download minor updates of this package on the Unity Asset Store or at ('http://j.gs/15Q0'). Do not distribute original content or modifications of the original content.

Please take a few moments to read over the 'license.txt' file included.

Sincerely,
W3Geek